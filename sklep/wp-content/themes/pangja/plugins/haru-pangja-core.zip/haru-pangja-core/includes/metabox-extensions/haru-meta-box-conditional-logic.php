<?php
/**
 *  
 * @package    HaruTheme
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

// Load the conditional logic and assets
require_once PLUGIN_HARU_PANGJA_CORE_DIR . '/includes/metabox-extensions/conditional-logic/class-conditional-logic.php';

new Haru_MB_Conditional_Logic;