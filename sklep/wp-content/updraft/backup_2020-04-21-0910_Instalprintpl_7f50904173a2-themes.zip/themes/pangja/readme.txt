=== Haru Pangja ===
Contributors: HaruTheme
Requires at least: WordPress 4.5
Tested up to: WordPress 4.7
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, left-sidebar, post-formats, sticky-post, threaded-comments, translation-ready, blog, woocommerce

== Description ==
Haru Pangja will make your WordPress look beautiful everywhere.

* Mobile-first, Responsive Layout
* Social Links
* Post Formats
* The GPL v2.0 or later license. :) Use it to make something cool.

For more information about Haru Pangja please go to https://harutheme.com

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.

== Copyright ==

Haru Pangja WordPress Theme, Copyright 2017 harutheme.com
Haru Pangja is distributed under the terms of the GNU GPL

== Changelog ==
